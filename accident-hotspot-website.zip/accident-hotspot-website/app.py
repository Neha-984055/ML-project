from flask import Flask, render_template, request, jsonify, send_file
import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score, davies_bouldin_score
from io import BytesIO

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 25 * 1024 * 1024
EARTH_KM = 6371.0
CITY_EPS_KM = {'Bangalore': 2.0, 'Chandigarh': 0.9, 'Chennai': 1.4, 'Delhi': 2.4,
               'Hyderabad': 2.0, 'Kolkata': 1.4, 'Mumbai': 1.9, 'Pune': 1.2}
CITY_COORDS = {
    'Bangalore': (12.9716, 77.5946), 'Chandigarh': (30.7333, 76.7794),
    'Chennai': (13.0827, 80.2707), 'Delhi': (28.6139, 77.2090),
    'Hyderabad': (17.3850, 78.4867), 'Kolkata': (22.5726, 88.3639),
    'Mumbai': (19.0760, 72.8777), 'Pune': (18.5204, 73.8567)
}

# The built-in demo is explicitly synthetic so the dashboard works before the user's Kaggle CSV is uploaded.
def make_demo_data():
    rng = np.random.default_rng(42)
    rows = []
    causes = ['Overspeeding', 'Distracted Driving', 'Poor Road Conditions', 'Weather', 'Signal Violation']
    weathers = ['Clear', 'Rainy', 'Foggy', 'Cloudy']
    densities = ['Low', 'Medium', 'High']
    severities = ['Minor', 'Major', 'Fatal']
    for city, (lat, lon) in CITY_COORDS.items():
        # Three plausible synthetic concentrations around each city centre; not real incident locations.
        offsets = [(0.0, 0.0), (0.045, 0.035), (-0.04, 0.055)]
        for cluster_idx, (dlat, dlon) in enumerate(offsets):
            n = int(rng.integers(36, 66))
            for _ in range(n):
                rows.append({
                    'city': city, 'state': 'Demo state',
                    'latitude': lat + dlat + rng.normal(0, 0.006),
                    'longitude': lon + dlon + rng.normal(0, 0.006),
                    'date': str((pd.Timestamp('2024-01-01') + pd.Timedelta(days=int(rng.integers(0, 700)))).date()),
                    'hour': int(rng.integers(0, 24)), 'day_of_week': rng.choice(['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']),
                    'road_type': rng.choice(['Highway','Urban Road','Intersection','Residential Road']),
                    'weather': rng.choice(weathers), 'visibility': float(rng.uniform(1, 10)),
                    'cause': rng.choice(causes, p=[.30,.22,.18,.12,.18]),
                    'accident_severity': rng.choice(severities, p=[.58,.30,.12]),
                    'vehicles_involved': int(rng.integers(1, 5)), 'casualties': int(rng.integers(0, 5)),
                    'traffic_density': rng.choice(densities), 'festival': rng.choice(['Yes','No'], p=[.08,.92]),
                    'risk_score': float(rng.uniform(0.1, 1.0)), '_demo_cluster': cluster_idx
                })
    return pd.DataFrame(rows)

DEMO_DF = make_demo_data()

def find_col(df, options, required=True):
    lookup = {str(c).strip().lower().replace(' ', '_'): c for c in df.columns}
    for option in options:
        key = option.lower().replace(' ', '_')
        if key in lookup: return lookup[key]
    if required: raise ValueError('Missing required column. Expected one of: ' + ', '.join(options))
    return None

def json_safe(v):
    if pd.isna(v): return None
    if isinstance(v, (np.integer,)): return int(v)
    if isinstance(v, (np.floating,)): return float(v)
    return v.item() if hasattr(v, 'item') else v

def analyze(df, source='Uploaded dataset', eps_override=None, min_samples=10):
    df = df.copy()
    lat_col = find_col(df, ['latitude','lat'])
    lon_col = find_col(df, ['longitude','lon','lng','long'])
    city_col = find_col(df, ['city'], required=False)
    if city_col is None:
        df['city'] = 'All records'; city_col = 'city'
    else:
        df[city_col] = df[city_col].fillna('Unknown').astype(str).str.strip()
    df['_lat'] = pd.to_numeric(df[lat_col], errors='coerce')
    df['_lon'] = pd.to_numeric(df[lon_col], errors='coerce')
    df = df.dropna(subset=['_lat','_lon']).copy()
    df = df[df['_lat'].between(-90,90) & df['_lon'].between(-180,180)]
    if len(df) < max(3, min_samples): raise ValueError('Not enough valid latitude/longitude rows to run DBSCAN. Please upload a larger CSV.')
    # City-wise DBSCAN is the project's chosen approach; Haversine works on radians.
    df['_cluster'] = -1
    eps_map = {}
    for city in df[city_col].unique():
        mask = df[city_col] == city
        eps_km = float(eps_override) if eps_override is not None else CITY_EPS_KM.get(city, 1.5)
        eps_map[str(city)] = eps_km
        coords = np.radians(df.loc[mask, ['_lat','_lon']].to_numpy())
        labels = DBSCAN(eps=eps_km/EARTH_KM, min_samples=int(min_samples), metric='haversine', algorithm='ball_tree').fit_predict(coords)
        # Unique cluster labels across cities; keep -1 as noise.
        offset = int(df['_cluster'].max()) + 1
        if offset < 0: offset = 0
        mapped = np.where(labels == -1, -1, labels + offset)
        df.loc[mask, '_cluster'] = mapped
    df['_cluster'] = df['_cluster'].astype(int)
    cluster_rows = []
    city_name = city_col
    severity_col = find_col(df, ['accident_severity','severity'], required=False)
    cause_col = find_col(df, ['cause','accident_cause','primary_cause'], required=False)
    weather_col = find_col(df, ['weather','weather_condition'], required=False)
    density_col = find_col(df, ['traffic_density','traffic'], required=False)
    for (city, label), group in df[df['_cluster'] >= 0].groupby([city_name, '_cluster']):
        counts = group[severity_col].astype(str).str.lower().value_counts() if severity_col else pd.Series(dtype=int)
        cluster_rows.append({'city': str(city), 'cluster_id': int(label), 'accidents': int(len(group)),
            'latitude': float(group['_lat'].mean()), 'longitude': float(group['_lon'].mean()),
            'fatal': int(sum(counts[k] for k in counts.index if 'fatal' in k)),
            'major': int(sum(counts[k] for k in counts.index if 'major' in k or 'serious' in k)),
            'minor': int(sum(counts[k] for k in counts.index if 'minor' in k or 'moderate' in k)),
            'top_cause': str(group[cause_col].mode().iloc[0]) if cause_col and not group[cause_col].dropna().empty else 'Not available',
            'top_weather': str(group[weather_col].mode().iloc[0]) if weather_col and not group[weather_col].dropna().empty else 'Not available',
            'traffic_density': str(group[density_col].mode().iloc[0]) if density_col and not group[density_col].dropna().empty else 'Not available'})
    hotspots = pd.DataFrame(cluster_rows)
    if len(hotspots):
        lo, hi = hotspots['accidents'].quantile([.33,.66]).tolist()
        hotspots['risk_level'] = hotspots['accidents'].apply(lambda n: 'Low' if n <= lo else ('Medium' if n <= hi else 'High'))
        hotspots = hotspots.sort_values(['accidents','city'], ascending=[False, True])
    labels = df['_cluster'].to_numpy()
    noise_count = int((labels == -1).sum())
    valid = df[df['_cluster'] >= 0]
    sil = dbi = None
    if len(valid) >= 3 and valid['_cluster'].nunique() >= 2 and len(valid) <= 5000:
        # Approximate local kilometre projection for internal diagnostic metrics.
        lat0 = np.radians(valid['_lat'].mean())
        xy = np.column_stack([np.radians(valid['_lat'].to_numpy())*EARTH_KM,
                              np.radians(valid['_lon'].to_numpy())*EARTH_KM*np.cos(lat0)])
        try:
            sil = float(silhouette_score(xy, valid['_cluster'].to_numpy()))
            dbi = float(davies_bouldin_score(xy, valid['_cluster'].to_numpy()))
        except Exception: pass
    # Data summaries for dashboard charts
    def count_map(col, limit=12):
        if not col: return []
        vc = df[col].fillna('Unknown').astype(str).value_counts().head(limit)
        return [{'label': str(k), 'value': int(v)} for k,v in vc.items()]
    hour_col = find_col(df, ['hour','accident_hour'], required=False)
    city_counts = df[city_name].astype(str).value_counts().sort_values(ascending=False)
    severity = count_map(severity_col)
    hourly = []
    if hour_col:
        h = pd.to_numeric(df[hour_col], errors='coerce').dropna().astype(int)
        hourly = [{'label': str(i), 'value': int((h == i).sum())} for i in range(24)]
    result_rows = []
    for _, r in df.head(12000).iterrows():
        result_rows.append({'city': str(r[city_name]), 'latitude': float(r['_lat']), 'longitude': float(r['_lon']), 'cluster': int(r['_cluster']),
          'severity': str(r[severity_col]) if severity_col and pd.notna(r[severity_col]) else 'Unknown',
          'cause': str(r[cause_col]) if cause_col and pd.notna(r[cause_col]) else 'Unknown'})
    return {'source': source, 'records': int(len(df)), 'cities': int(df[city_name].nunique()),
      'cluster_count': int(df.loc[df['_cluster'] >= 0, '_cluster'].nunique()), 'noise_count': noise_count,
      'noise_pct': round(noise_count/len(df)*100, 2), 'silhouette': round(sil, 4) if sil is not None else None,
      'davies_bouldin': round(dbi, 4) if dbi is not None else None, 'eps_map': eps_map, 'min_samples': int(min_samples),
      'city_counts': [{'label': str(k), 'value': int(v)} for k,v in city_counts.items()], 'severity': severity,
      'causes': count_map(cause_col), 'density': count_map(density_col), 'weather': count_map(weather_col), 'hourly': hourly,
      'hotspots': hotspots.to_dict(orient='records') if len(hotspots) else [], 'points': result_rows,
      'columns': [str(c) for c in df.columns if not str(c).startswith('_')],
      'note': 'DBSCAN clusters spatial concentrations in historical records. Risk levels are relative to detected cluster counts, not accident probabilities.'}

@app.get('/')
def home(): return render_template('index.html')

@app.get('/api/demo')
def demo():
    try: return jsonify(analyze(DEMO_DF.drop(columns=['_demo_cluster']), 'Built-in synthetic demo data'))
    except Exception as e: return jsonify({'error': str(e)}), 400

@app.post('/api/analyze')
def upload_and_analyze():
    try:
        file = request.files.get('file')
        if not file or not file.filename.lower().endswith('.csv'):
            return jsonify({'error':'Please choose a CSV file downloaded from Kaggle.'}), 400
        df = pd.read_csv(file)
        eps = request.form.get('eps_km', '').strip()
        eps = float(eps) if eps else None
        min_samples = int(request.form.get('min_samples', '10'))
        if min_samples < 2 or min_samples > 100: raise ValueError('min_samples must be between 2 and 100.')
        if eps is not None and not (0.1 <= eps <= 10): raise ValueError('eps must be between 0.1 and 10 km.')
        return jsonify(analyze(df, file.filename, eps, min_samples))
    except Exception as e: return jsonify({'error': str(e)}), 400

@app.post('/api/export')
def export_results():
    payload = request.get_json(silent=True) or {}
    rows = payload.get('hotspots', [])
    if not rows: return jsonify({'error':'No hotspot results to export yet.'}), 400
    buf = BytesIO(pd.DataFrame(rows).to_csv(index=False).encode('utf-8'))
    return send_file(buf, mimetype='text/csv', as_attachment=True, download_name='detected_hotspots.csv')

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=False)
