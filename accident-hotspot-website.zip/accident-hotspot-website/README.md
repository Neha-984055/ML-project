# RoadLens — Accident Hotspot Detection

A standalone Flask website for the **Accident Hotspot Detection Using DBSCAN-Based Anomaly Detection** project. It does not connect to Google Colab and runs the clustering algorithm on the local machine/server.

## Quick start (Windows)
1. Install Python 3.10 or newer from https://www.python.org/downloads/ (tick **Add Python to PATH**).
2. Extract this folder.
3. Open Command Prompt in this folder and run:
   ```bat
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
   ```
4. Open **http://127.0.0.1:5000** in Chrome.

## Use your actual Kaggle dataset
1. Download the CSV from https://www.kaggle.com/datasets/sehaj1104/indian-road-accident-dataset-20222025
2. In the website, choose the CSV and click **Run DBSCAN analysis**.
3. The app requires latitude and longitude (or lat/lon) columns. A city column is recommended for the project's city-wise clustering. It recognises common alternatives such as `lat`, `lng`, and `long`.
4. Default city-wise eps values (km) and `min_samples=10` follow the project notes. If you set a single eps override, it is applied to each city.

## Important data note
The **Load demo data** button uses generated synthetic records so the website is immediately demonstrable. Those records are not from Kaggle and must not be presented as real accident data. Upload the real Kaggle CSV for project results.

## ML included
- City-wise DBSCAN using the Haversine metric on latitude/longitude converted to radians
- Project city-specific eps values and `min_samples=10`
- Noise-point count and percentage (`cluster = -1`)
- Silhouette Score and Davies–Bouldin Index when calculable (diagnostics, not classification accuracy)
- EDA summaries for city, severity, hour, causes, weather and traffic density when those columns exist
- Hotspot summaries with relative Low/Medium/High labels based on the 33rd and 66th percentiles of cluster record counts
- CSV export of detected hotspot summaries

## About the “live website”
This is a complete working local website, but it is not hosted on a public URL. A public live URL requires deployment to a hosting provider and uploading the project there. The map tiles and chart libraries use public CDNs, so internet access improves the visual experience.
